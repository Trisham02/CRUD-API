﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using CRUD_Operations.Models;

namespace CRUD_Operations.Controllers
{
    public class T_CustomersController : ApiController
    {
        private AdventureWorks2017Entities db = new AdventureWorks2017Entities();

        // GET: api/T_Customers
        public IQueryable<T_Customers> GetT_Customers()
        {
            return db.T_Customers;
        }

        // GET: api/T_Customers/5
        [ResponseType(typeof(T_Customers))]
        public async Task<IHttpActionResult> GetT_Customers(int id)
        {
            T_Customers t_Customers = await db.T_Customers.FindAsync(id);
            if (t_Customers == null)
            {
                return NotFound();
            }

            return Ok(t_Customers);
        }

        // PUT: api/T_Customers/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutT_Customers(int id, T_Customers t_Customers)
        {
            if (id != t_Customers.C_Id)
            {
                return BadRequest();
            }

            db.Entry(t_Customers).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!T_CustomersExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/T_Customers
        [ResponseType(typeof(T_Customers))]
        public async Task<IHttpActionResult> PostT_Customers(T_Customers t_Customers)
        {
            db.T_Customers.Add(t_Customers);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (T_CustomersExists(t_Customers.C_Id))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = t_Customers.C_Id }, t_Customers);
        }

        // DELETE: api/T_Customers/5
        [ResponseType(typeof(T_Customers))]
        public async Task<IHttpActionResult> DeleteT_Customers(int id)
        {
            T_Customers t_Customers = await db.T_Customers.FindAsync(id);
            if (t_Customers == null)
            {
                return NotFound();
            }

            db.T_Customers.Remove(t_Customers);
            await db.SaveChangesAsync();

            return Ok(t_Customers);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool T_CustomersExists(int id)
        {
            return db.T_Customers.Count(e => e.C_Id == id) > 0;
        }
    }
}